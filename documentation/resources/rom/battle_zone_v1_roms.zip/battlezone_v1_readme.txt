BATTLEZONE ROM PLACEMENT (Version 1)

Copyright 1980 by Atari. Program by Ed Rotberg and Owen Rubin.
-------------------------------------------------------------


Battlezone (Version 1)
NAME			LOCATION	SIZE	CHECKSUM	NOTE
---------------		--------	----	--------	----
Bzone36.409.bin		N1		2716	f3f9
Bzone36.410.bin		L/M1		2716	0c8d
Bzone36.411.bin		K1		2716	be51
Bzone36.412.bin		J1		2716	5af7
Bzone36.413.bin		F/H1		2716	0b4f
Bzone36.414.bin		E1		2716	412d		Modified for Ver. 2
Bzone36.421.bin		A3		2716	aadd
Bzone36.422.bin		B/C3		2716	cbd1



The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7



-----------------------------------------------------
|                        END                        |
-----------------------------------------------------